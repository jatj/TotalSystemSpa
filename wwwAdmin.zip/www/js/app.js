// Ionic Starter App
// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.controllers' is found in controllers.js
angular.module('starter', ['ionic', 'starter.controllers', 'starter.services', 'firebase'])

.run(function($ionicPlatform) {
    $ionicPlatform.ready(function() {
        // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
        // for form inputs)
        if (window.cordova && window.cordova.plugins.Keyboard) {
            cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
            cordova.plugins.Keyboard.disableScroll(true);

        }
        if (window.StatusBar) {
            // org.apache.cordova.statusbar required
            StatusBar.styleDefault();
        }
    });
})

.config(function($stateProvider, $urlRouterProvider) {
    $stateProvider

        .state('app', {
        url: '/app',
        abstract: true,
        templateUrl: 'templates/menu.html',
        controller: 'AppCtrl'
    })

    .state('app.chats', {
        url: '/chats',
        views: {
            'menuContent': {
                templateUrl: 'templates/chats.html',
                controller: 'ChatsCtrl'
            }
        }
    })

    .state('app.chat-detail', {
        url: '/chats/:chatId/:chatName',
        views: {
            'menuContent': {
                templateUrl: 'templates/chat-detail.html',
                controller: 'ChatDetailCtrl'
            }
        }
    })

    .state('app.personal', {
        url: '/personal',
        views: {
            'menuContent': {
                templateUrl: 'templates/personal.html',
                controller: 'PersonalCtrl'
            }
        }
    })

    .state('app.personal-detail', {
        url: '/personal/:personalId/:personalName',
        views: {
            'menuContent': {
                templateUrl: 'templates/personal-detail.html',
                controller: 'PersonalDetailCtrl'
            }
        }
    })

    .state('app.cabinas', {
        url: '/cabinas',
        views: {
            'menuContent': {
                templateUrl: 'templates/cabinas.html',
                controller: 'CabinasCtrl'
            }
        }
    })

    .state('app.cabina-detail', {
        url: '/cabinas/:cabinaId/:cabinaName',
        views: {
            'menuContent': {
                templateUrl: 'templates/cabina-detail.html',
                controller: 'CabinaDetailCtrl'
            }
        }
    })

    .state('app.servicios', {
        url: '/servicios',
        views: {
            'menuContent': {
                templateUrl: 'templates/servicios.html',
                controller: 'ServiciosCtrl'
            }
        }
    })

    .state('app.servicios-detail', {
        url: '/servicios/:servicioId/:servicioName',
        views: {
            'menuContent': {
                templateUrl: 'templates/servicios-detail.html',
                controller: 'ServiciosDetailCtrl'
            }
        }
    })

    .state('app.single', {
        url: '/playlists/:playlistId',
        views: {
            'menuContent': {
                templateUrl: 'templates/playlist.html',
                controller: 'PlaylistCtrl'
            }
        }
    });
    // if none of the above states are matched, use this as the fallback
    $urlRouterProvider.otherwise('/app/chats');
});