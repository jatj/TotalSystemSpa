angular.module('starter.controllers', [])

.controller('AppCtrl', function($scope, $ionicModal, $timeout) {

    // With the new view caching in Ionic, Controllers are only called
    // when they are recreated or on app start, instead of every page change.
    // To listen for when this page is active (for example, to refresh data),
    // listen for the $ionicView.enter event:
    //$scope.$on('$ionicView.enter', function(e) {
    //});

    // Form data for the login modal
    $scope.loginData = {};

    // Create the login modal that we will use later
    $ionicModal.fromTemplateUrl('templates/login.html', {
        scope: $scope
    }).then(function(modal) {
        $scope.modal = modal;
    });

    // Triggered in the login modal to close it
    $scope.closeLogin = function() {
        $scope.modal.hide();
    };

    // Open the login modal
    $scope.login = function() {
        $scope.modal.show();
    };

    // Perform the login action when the user submits the login form
    $scope.doLogin = function() {
        console.log('Doing login', $scope.loginData);

        // Simulate a login delay. Remove this and replace with your login
        // code if using a login system
        $timeout(function() {
            $scope.closeLogin();
        }, 1000);
    };
})

.controller('PlaylistsCtrl', function($scope) {
    $scope.playlists = [{
        title: 'Reggae',
        id: 1
    }, {
        title: 'Chill',
        id: 2
    }, {
        title: 'Dubstep',
        id: 3
    }, {
        title: 'Indie',
        id: 4
    }, {
        title: 'Rap',
        id: 5
    }, {
        title: 'Cowbell',
        id: 6
    }];
})

.controller('ChatsCtrl', function($scope, Chats) {
    // With the new view caching in Ionic, Controllers are only called
    // when they are recreated or on app start, instead of every page change.
    // To listen for when this page is active (for example, to refresh data),
    // listen for the $ionicView.enter event:
    //
    //$scope.$on('$ionicView.enter', function(e) {
    //});

    $scope.chats = Chats.all();

    $scope.remove = function(chat) {
        Chats.remove(chat);
    };
})

.controller('ChatDetailCtrl', function($scope, $stateParams, $firebaseArray, Chats) {

    $scope.chatName = $stateParams.chatName;
    $scope.mensajes = Chats.get($stateParams.chatId);

    $scope.data = {};

    $scope.enviarMensaje = function() {
        $scope.mensajes.$add({
            nombre: 'Total System Spa',
            texto: $scope.data.mensaje
        });
    }
})

.controller('PersonalCtrl', function($scope, Personal, $ionicModal, $ionicLoading, $ionicPopup, $timeout) {

    $scope.sucursal = 'uno';
    $scope.personal = Personal.all($scope.sucursal);

    $scope.d = {};

    $scope.d.horario = {};

    $scope.abrirNuevoPersonal = function(){
        $scope.openModal();
    }

    $scope.agregarPersona = function(){
        $ionicLoading.show({
            template: 'Guardando...'
        }).then(function(){
            console.log("The loading indicator is now displayed");
        });
        $scope.d.horario = $("#day-schedule").data('artsy.dayScheduleSelector').serialize();
        $scope.personal.$add({
            nombre: $scope.d.nombre,
            correo: $scope.d.email,
            tel: $scope.d.tel,
            horario: $scope.d.horario
        }).then(function(ref){
            $ionicLoading.hide().then(function(){

                $scope.closeModal();

                var myPopup = $ionicPopup.show({
                    template: '<div class="correcto"><i class="icon ion-checkmark-circled"></i></div>',
                    title: 'Guardado Correctamente',
                    scope: $scope,
                });

                $timeout(function() {
                    myPopup.close(); //close the popup after 3 seconds for some reason
                }, 1500);

            });
        });
    }

    $ionicModal.fromTemplateUrl('templates/modal-personal.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function(modal) {
        $scope.modal = modal;
        $scope.modal.show();
        $scope.modal.hide();
    });

    $scope.openModal = function() {
        $scope.modal.show();
    };
    $scope.closeModal = function() {
        $scope.modal.hide();
    };

    $scope.$on('modal.hidden', function() {
        $("#day-schedule").dayScheduleSelector({
            //days: [1, 2, 3, 5, 6],
            interval: 30,
            startTime: '07:00',
            endTime: '20:00'
        });
        $("#day-schedule").on('selected.artsy.dayScheduleSelector', function (e, selected) {
            //alert(JSON.stringify($("#day-schedule").data('artsy.dayScheduleSelector').serialize()));
            
        });
        $("#day-schedule").data('artsy.dayScheduleSelector').deserialize({
            //'0': [['09:30', '10:00'], ['10:00', '10:30'], ['13:00', '16:30']]
        });
    });


})

.controller('CabinasCtrl', function($scope, Cabinas, $ionicModal, $ionicLoading, $ionicPopup, $timeout) {

    $scope.sucursal = 'uno';
    $scope.cabinas = Cabinas.all($scope.sucursal);

    $scope.d = {};

    $scope.d.horario = {};

    $scope.abrirNuevaCabina = function(){
        $scope.openModal();
    }

    $scope.agregarCabina = function(){
        $ionicLoading.show({
            template: 'Guardando...'
        }).then(function(){
            console.log("The loading indicator is now displayed");
        });
        //$scope.d.horario = $("#day-schedule").data('artsy.dayScheduleSelector').serialize();
        $scope.cabinas.$add({
            nombre: $scope.d.nombre,
            //horario: $scope.d.horario
        }).then(function(ref){
            $ionicLoading.hide().then(function(){

                $scope.closeModal();

                var myPopup = $ionicPopup.show({
                    template: '<div class="correcto"><i class="icon ion-checkmark-circled"></i></div>',
                    title: 'Guardado Correctamente',
                    scope: $scope,
                });

                $timeout(function() {
                    myPopup.close(); //close the popup after 3 seconds for some reason
                }, 1500);

            });
        });
    }

    $ionicModal.fromTemplateUrl('templates/modal-cabinas.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function(modal) {
        $scope.modal = modal;
        $scope.modal.show();
        $scope.modal.hide();
    });

    $scope.openModal = function() {
        $scope.modal.show();
    };
    $scope.closeModal = function() {
        $scope.modal.hide();
    };
    /*
    $scope.$on('modal.hidden', function() {
        $("#day-schedule").dayScheduleSelector({
            //days: [1, 2, 3, 5, 6],
            interval: 60,
            startTime: '07:00',
            endTime: '20:00'
        });
        $("#day-schedule").on('selected.artsy.dayScheduleSelector', function (e, selected) {
            //alert(JSON.stringify($("#day-schedule").data('artsy.dayScheduleSelector').serialize()));
            
        });
        $("#day-schedule").data('artsy.dayScheduleSelector').deserialize({
            //'0': [['09:30', '10:00'], ['10:00', '10:30'], ['13:00', '16:30']]
        });
    });
    */

})

.controller('CabinaDetailCtrl', function($scope, $state, $stateParams, $firebaseObject, Cabinas, $ionicLoading, $ionicPopup, $timeout) {

    $scope.cabinaName = $stateParams.cabinaName;
    $scope.sucursal = 'uno';

    $scope.cabina = Cabinas.get($scope.sucursal, $stateParams.cabinaId);

    $scope.actualizarCabina = function(){
        $ionicLoading.show({
            template: 'Actualizando...'
        }).then(function(){
            console.log("The loading indicator is now displayed");
        });

        $scope.cabina.$save().then(function(ref){
            $ionicLoading.hide().then(function(){

                var myPopup = $ionicPopup.show({
                    template: '<div class="correcto"><i class="icon ion-checkmark-circled"></i></div>',
                    title: 'Actualizado Correctamente',
                    scope: $scope,
                });

                $timeout(function() {
                    myPopup.close(); //close the popup after 3 seconds for some reason
                }, 1500);

            });
        });
    }

    $scope.eliminar = function(){
        var confirmPopup = $ionicPopup.confirm({
            title: 'Eliminar cabina',
            template: '¿Estas seguro de que deseas eliminar esta cabina?'
        });

        confirmPopup.then(function(res) {
            if(res) {
                //console.log('You are sure');
                $scope.cabina.$remove().then(function(){
                    var myPopup = $ionicPopup.show({
                        template: '<div class="correcto"><i class="icon ion-checkmark-circled"></i></div>',
                        title: 'Eliminada Correctamente',
                        scope: $scope,
                    });

                    $timeout(function() {
                        myPopup.close(); //close the popup after 3 seconds for some reason
                        $state.go('app.cabinas');
                    }, 1500);
                });
            } else {
                //console.log('You are not sure');
            }
        });   
    }

})

.controller('PersonalDetailCtrl', function($scope, $state, $stateParams, $firebaseObject, Personal, $ionicLoading, $ionicPopup, $timeout) {

    $scope.personalName = $stateParams.personalName;
    $scope.sucursal = 'uno';

    $scope.d = {};

    $scope.personal = Personal.get($scope.sucursal, $stateParams.personalId);

    $scope.personal.$loaded().then(function(){
        //alert(JSON.stringify($scope.personal.horario));

        $("#day-schedule").dayScheduleSelector({
            //days: [1, 2, 3, 5, 6],
            interval: 30,
            startTime: '07:00',
            endTime: '20:00'
        });
        $("#day-schedule").on('selected.artsy.dayScheduleSelector', function (e, selected) {
            //alert(JSON.stringify($("#day-schedule").data('artsy.dayScheduleSelector').serialize()));
            
        });
        $("#day-schedule").data('artsy.dayScheduleSelector').deserialize({
            //'0': [['09:30', '10:00'], ['10:00', '10:30'], ['13:00', '16:30']]
            '0': $scope.personal.horario[0],
            '1': $scope.personal.horario[1],
            '2': $scope.personal.horario[2],
            '3': $scope.personal.horario[3],
            '4': $scope.personal.horario[4],
            '5': $scope.personal.horario[5],
            '6': $scope.personal.horario[6]
        });
    });

    $scope.actualizarPersona = function(){
        $ionicLoading.show({
            template: 'Actualizando...'
        }).then(function(){
            console.log("The loading indicator is now displayed");
        });
        $scope.personal.horario = $("#day-schedule").data('artsy.dayScheduleSelector').serialize();
        $scope.personal.$save().then(function(ref){
            $ionicLoading.hide().then(function(){

                var myPopup = $ionicPopup.show({
                    template: '<div class="correcto"><i class="icon ion-checkmark-circled"></i></div>',
                    title: 'Actualizado Correctamente',
                    scope: $scope,
                });

                $timeout(function() {
                    myPopup.close(); //close the popup after 3 seconds for some reason
                }, 1500);

            });
        });
    }

    $scope.eliminar = function(){
        var confirmPopup = $ionicPopup.confirm({
            title: 'Eliminar persona',
            template: '¿Estas seguro de que deseas eliminar esta persona?'
        });

        confirmPopup.then(function(res) {
            if(res) {
                //console.log('You are sure');
                $scope.personal.$remove().then(function(){
                    var myPopup = $ionicPopup.show({
                        template: '<div class="correcto"><i class="icon ion-checkmark-circled"></i></div>',
                        title: 'Eliminada Correctamente',
                        scope: $scope,
                    });

                    $timeout(function() {
                        myPopup.close(); //close the popup after 3 seconds for some reason
                        $state.go('app.personal');
                    }, 1500);
                });
            } else {
                //console.log('You are not sure');
            }
        });   
    }

})

.controller('ServiciosCtrl', function($scope, Servicios, Personal, Cabinas, $ionicModal, $ionicLoading, $ionicPopup, $timeout) {

    $(".timing").timingfield();

    $scope.sucursal = 'uno';

    $scope.servicios = Servicios.all($scope.sucursal);
    $scope.personal = Personal.all($scope.sucursal);
    $scope.cabinas = Cabinas.all($scope.sucursal);

    $scope.d = {};

    $scope.d.personalCapaces = new Array();
    $scope.d.cabinasCapaces = new Array();

    $scope.personalFinal = new Array();
    $scope.cabinasFinal = new Array();

    $scope.abrirNuevoServicio = function(){
        $scope.openModal();
    }

    $scope.agregarServicio = function(){

        $ionicLoading.show({
            template: 'Creando...'
        }).then(function(){
            console.log("The loading indicator is now displayed");
        });

        for(var i = 0; i < $scope.personal.length; i++){
            if($scope.d.personalCapaces[i]){
                //alert(JSON.stringify($scope.personal[i]));
                var persona = {
                    nombre: $scope.personal[i].nombre,
                    id: $scope.personal[i].$id
                };
                $scope.personalFinal.push(persona);
            }
        }

        for(var i = 0; i < $scope.cabinas.length; i++){
            if($scope.d.cabinasCapaces[i]){
                //alert(JSON.stringify($scope.personal[i]));
                var cabina = {
                    nombre: $scope.cabinas[i].nombre,
                    id: $scope.cabinas[i].$id
                };
                $scope.cabinasFinal.push(cabina);
            }
        }

        $scope.d.horas = $('#horas').val();
        $scope.d.minutos = $('#minutos').val();

        alert('Horas: ' + $scope.d.horas);
        alert('mnts: ' + $scope.d.minutos);

        $scope.servicios.$add({
            nombre: $scope.d.nombre,
            descripcion: $scope.d.descripcion,
            costo: $scope.d.costo,
            personal: $scope.personalFinal,
            cabinas: $scope.cabinasFinal,
            duracion: {
                horas: $scope.d.horas,
                minutos: $scope.d.minutos
            }
        }).then(function(ref){
            $ionicLoading.hide().then(function(){

                $scope.closeModal();

                var myPopup = $ionicPopup.show({
                    template: '<div class="correcto"><i class="icon ion-checkmark-circled"></i></div>',
                    title: 'Creado Correctamente',
                    scope: $scope,
                });

                $timeout(function() {
                    myPopup.close(); //close the popup after 3 seconds for some reason
                }, 1500);
            });
        });
    }

    $ionicModal.fromTemplateUrl('templates/modal-servicios.html', {
        scope: $scope,
        animation: 'slide-in-up'
    }).then(function(modal) {
        $scope.modal = modal;
        $scope.modal.show();
        $(".timing").timingfield();
        $scope.modal.hide();
    });

    $scope.openModal = function() {
        $scope.modal.show();
    };
    $scope.closeModal = function() {
        $scope.modal.hide();
    };


})

.controller('ServiciosDetailCtrl', function($scope, $state, $stateParams, $firebaseObject, Servicios, Personal, Cabinas, $ionicLoading, $ionicPopup, $timeout) {

    $(".timing").timingfield();

    $scope.servicioName = $stateParams.servicioName;
    $scope.idServicio = $stateParams.servicioId;
    $scope.sucursal = 'uno';

    $scope.servicio = Servicios.get($scope.sucursal, $scope.idServicio);

    $scope.personal = Personal.all($scope.sucursal);
    $scope.cabinas = Cabinas.all($scope.sucursal);

    $scope.d = {};

    $scope.d.personalCapaces = new Array();
    $scope.d.cabinasCapaces = new Array();

    $scope.personalFinal = new Array();
    $scope.cabinasFinal = new Array();


    // Activar las casillas que ya están seleccionadas
    $scope.personal.$loaded().then(function(){ 
        for(var i = 0; i < $scope.personal.length; i++){
            for(var j = 0; j < $scope.servicio.personal.length; j++){
                if($scope.personal[i].$id == $scope.servicio.personal[j].id){
                    $scope.d.personalCapaces[i] = true;
                }
            }
        }
    })

    $scope.cabinas.$loaded().then(function(){
        for(var i = 0; i < $scope.cabinas.length; i++){
            for(var j = 0; j < $scope.servicio.cabinas.length; j++){
                if($scope.cabinas[i].$id == $scope.servicio.cabinas[j].id){
                    $scope.d.cabinasCapaces[i] = true;
                }
            }
        }
    })

    $scope.servicio.$loaded().then(function(){
        $('#horas').val($scope.servicio.duracion.horas);
        $('#minutos').val($scope.servicio.duracion.minutos);
    });

    $scope.actualizarServicio = function(){

        $ionicLoading.show({
            template: 'Actualizando...'
        }).then(function(){
            console.log("The loading indicator is now displayed");
        });

        for(var i = 0; i < $scope.personal.length; i++){
            if($scope.d.personalCapaces[i]){
                //alert(JSON.stringify($scope.personal[i]));
                var persona = {
                    nombre: $scope.personal[i].nombre,
                    id: $scope.personal[i].$id
                };
                $scope.personalFinal.push(persona);
            }
        }
        $scope.servicio.personal = $scope.personalFinal;

        for(var i = 0; i < $scope.cabinas.length; i++){
            if($scope.d.cabinasCapaces[i]){
                //alert(JSON.stringify($scope.personal[i]));
                var cabina = {
                    nombre: $scope.cabinas[i].nombre,
                    id: $scope.cabinas[i].$id
                };
                $scope.cabinasFinal.push(cabina);
            }
        }
        $scope.servicio.cabinas = $scope.cabinasFinal;
        //alert($scope.servicio.cabinas);

        $scope.servicio.duracion.horas = $('#horas').val();
        $scope.servicio.duracion.minutos = $('#minutos').val();

        $scope.servicio.$save().then(function(ref){
            $ionicLoading.hide().then(function(){

                $scope.personalFinal = [];
                $scope.cabinasFinal = [];

                var myPopup = $ionicPopup.show({
                    template: '<div class="correcto"><i class="icon ion-checkmark-circled"></i></div>',
                    title: 'Actualizado Correctamente',
                    scope: $scope,
                });

                $timeout(function() {
                    myPopup.close(); //close the popup after 3 seconds for some reason
                }, 1500);

            });
        });
    }

    $scope.eliminar = function(){
        var confirmPopup = $ionicPopup.confirm({
            title: 'Eliminar servicio',
            template: '¿Estas seguro de que deseas eliminar este servicio?'
        });

        confirmPopup.then(function(res) {
            if(res) {
                //console.log('You are sure');
                $scope.servicio.$remove().then(function(){
                    var myPopup = $ionicPopup.show({
                        template: '<div class="correcto"><i class="icon ion-checkmark-circled"></i></div>',
                        title: 'Eliminado Correctamente',
                        scope: $scope,
                    });

                    $timeout(function() {
                        myPopup.close(); //close the popup after 3 seconds for some reason
                        $state.go('app.servicios');
                    }, 1500);
                });
            } else {
                //console.log('You are not sure');
            }
        });   
    }

})

.controller('PlaylistCtrl', function($scope, $stateParams) {});



