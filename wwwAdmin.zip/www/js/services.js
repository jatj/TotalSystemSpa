angular.module('starter.services', [])

.factory('Chats', function($firebaseObject, $firebaseArray, $q) {

  return {
    all: function() {
      var refChats = firebase.database().ref('chats');
      var query = refChats.orderByChild('votos');

      return $firebaseArray(query);
    },
    remove: function(chat) {
      chats.splice(chats.indexOf(chat), 1);
    },
    get: function(chatId) {
      var refMensajes = firebase.database().ref('chats/' + chatId + '/mensajes');

      return $firebaseArray(refMensajes);
    },
    crearChat: function(){
      var deferred = $q.defer();
      var messageListRef = firebase.database().ref('chats');
      var newMessageRef = messageListRef.push();
      newMessageRef.set({
        'nombre': 'Anónimo',
        'mensaje': {}
      }).then(function(){
        deferred.resolve(newMessageRef.key);
      });
      return deferred.promise;
    }
  };
})

.factory('Personal', function($firebaseObject, $firebaseArray, $q) {

  return {
    all: function(sucursal) {
      var refChats = firebase.database().ref(sucursal + '/personal');
      var query = refChats.orderByChild('votos');

      return $firebaseArray(query);
    },
    remove: function(chat) {
      chats.splice(chats.indexOf(chat), 1);
    },
    get: function(sucursal, personalId) {
      var refPersonal = firebase.database().ref(sucursal + '/personal/' + personalId);

      return $firebaseObject(refPersonal);
    }
  };
})

.factory('Cabinas', function($firebaseObject, $firebaseArray, $q) {

  return {
    all: function(sucursal) {
      var refChats = firebase.database().ref(sucursal + '/cabinas');
      var query = refChats.orderByChild('votos');

      return $firebaseArray(query);
    },
    remove: function(chat) {
      chats.splice(chats.indexOf(chat), 1);
    },
    get: function(sucursal, cabinaId) {
      var refPersonal = firebase.database().ref(sucursal + '/cabinas/' + cabinaId);

      return $firebaseObject(refPersonal);
    }
  };
})

.factory('Servicios', function($firebaseObject, $firebaseArray, $q) {

  return {
    all: function(sucursal) {
      var refChats = firebase.database().ref(sucursal + '/servicios');
      var query = refChats.orderByChild('votos');

      return $firebaseArray(query);
    },
    remove: function(chat) {
      chats.splice(chats.indexOf(chat), 1);
    },
    get: function(sucursal, servicioId) {
      var refPersonal = firebase.database().ref(sucursal + '/servicios/' + servicioId);

      return $firebaseObject(refPersonal);
    }
  };
})

;
