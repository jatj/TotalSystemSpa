angular.module('starter.controllers', [])

.controller('AppCtrl', function($scope, $ionicModal, $timeout) {

  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //$scope.$on('$ionicView.enter', function(e) {
  //});

  // Form data for the login modal
  $scope.loginData = {};

  // Create the login modal that we will use later
  $ionicModal.fromTemplateUrl('templates/login.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.modalLogin = modal;
  });

  // Triggered in the login modal to close it
  $scope.closeLogin = function() {
    $scope.modalLogin.hide();
  };

  // Open the login modal
  $scope.login = function() {
    $scope.modalLogin.show();
  };

  // Perform the login action when the user submits the login form
  $scope.doLogin = function() {
    console.log('Doing login', $scope.loginData);
    // Simulate a login delay. Remove this and replace with your login
    // code if using a login system
    $timeout(function() {
      $scope.closeLogin();
    }, 1000);
  };
})
.controller('PromocionesCtrl', function($scope) {
  $scope.promociones = [
    {title:'Relajación al 2x1',schedule:'lunes a viernes',image:'img/relajación-masajes--servicios.jpg'}
  ]
})
.controller('SucursalesCtrl', ['$scope', '$sce', function($scope,$sce) {
  $scope.sucursales=[
    {name:'Pedregal',location:'Sports World Pedregal Plaza Acora Ladera #16, Jardines del pedregal de San Ángel',
    map:$sce.trustAsHtml('<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3765.4654043475184!2d-99.20485233564716!3d19.305600786956553!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85cdffc49b0ffbf9%3A0xa27e9c81aea60b8!2sSports+World!5e0!3m2!1ses!2smx!4v1476026182097" class="img-responsive" frameborder="0" style="border:0" allowfullscreen></iframe>'),
    schedule:'Lunes a viernes de 9:00 a 18:00',phone:'5555-5555'},
    {name:'San Angel',location:'Sports World San Ángel Fernando M. Villalpando #98, Álvaro Obregón Guadalupe Inn',
    map:$sce.trustAsHtml('<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3764.371022550301!2d-99.1892697856463!3d19.353081086929507!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x85d1fff6603dc7af%3A0x3ba5d96d2e5cd101!2sSports+World+San+Angel!5e0!3m2!1ses!2smx!4v1476044314445" class="img-responsive" frameborder="0" style="border:0" allowfullscreen></iframe>'),
    schedule:'Lunes a viernes de 9:00 a 18:00',phone:'5555-5555'}
  ];

  $scope.miSucursal=$sce.trustAsHtml('<span class="miSucursal pull-right ion-checkmark-circled"></span>');
  $scope.setSucursal = function(sucursal){
    localStorage.setItem("sucursal", sucursal);
  }
  $scope.getSucursal = function(){
    return localStorage.getItem("sucursal");
  }
  $scope.checkSucursal = function(sucursal){
    if(localStorage.getItem("sucursal")==sucursal){
      return true;
    }else{
      return false;
    }
  }
}])
.controller('ServiciosCtrl', function($scope, $stateParams) {
  $scope.servicios = [
    { title: 'Salud', id: 0 ,image: "img/salud-facial-servicios.jpg", description:"Aqui va la descripcion del servicio.",
      subServicios: [
            {title: 'Faciales',description:'Aqui va la descripcion',price:'$100.00'},
            {title: 'Corporales',description:'Aqui va la descripcion',price:'$100.00'},
            {title: 'Desintoxicantes',description:'Aqui va la descripcion',price:'$100.00'}
            ]},
    { title: 'Belleza', id: 1 ,image: "img/belleza-extensiones-de-cabello-servicios.jpg", description:"Aqui va la descripcion del servicio.",
      subServicios: [
            {title: 'Piernas',description:'Aqui va la descripcion',price:'$100.00'},
            {title: 'Pestañas',description:'Aqui va la descripcion',price:'$100.00'},
            {title: 'Cejas',description:'Aqui va la descripcion',price:'$100.00'},
            {title: 'Cabello',description:'Aqui va la descripcion',price:'$100.00'},
            {title: 'Manipedi',description:'Aqui va la descripcion',price:'$100.00'}
            ]},
    { title: 'Relajación', id: 2 ,image: "img/relajación-masajes--servicios.jpg", description:"Aqui va la descripcion del servicio.",
      subServicios: [
            {title: 'Masajes',description:'Aqui va la descripcion',price:'$100.00'},
            {title: 'Rituales',description:'Aqui va la descripcion',price:'$100.00'}
            ]}
  ];
  $scope.servicio=$scope.servicios[$stateParams.id];

  for (var i = 0; i < $scope.servicios.length; i++){
    var servicio = $scope.servicios[i];
    if(servicio['title']==$stateParams.category){
      var subServicios = servicio['subServicios'];
      for(var j = 0; j<subServicios.length; j++){
        var subServicio = subServicios[j];
        if(subServicio['title']==$stateParams.service){
          $scope.servicioAgendar = subServicio;
          $scope.categoriaAgendar = $stateParams.category;
          $scope.imagenAgendar = servicio.image;
          $("#datepicker").datepicker();
        }
      }
    }
  }
});
